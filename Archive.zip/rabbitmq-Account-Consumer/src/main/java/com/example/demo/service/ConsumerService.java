package com.example.demo.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.ConsumerDao;
import com.example.demo.model.Account;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ConsumerService {

	private ConsumerDao consumerDao;
	
	
	private static final String QUEUE = "items-queue";

	@RabbitListener(queues = QUEUE)
	public void receiveMessage(Account account) {

		consumerDao.save(account);
		
	}
	
	
	public List<Account> showall()
	{
		Iterator<Account> it=consumerDao.findAll().iterator();
		List<Account> li = new ArrayList<Account>();
		while(it.hasNext())
		{
			li.add(it.next());
		}
		return li;
		
	}
	
	public Account showByid(int id)
	{
		return consumerDao.findById(id).get();
	}
	
}
