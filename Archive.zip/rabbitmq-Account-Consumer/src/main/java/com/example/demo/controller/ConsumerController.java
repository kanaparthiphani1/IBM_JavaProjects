package com.example.demo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Account;
import com.example.demo.service.ConsumerService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@Api(value = "Account Information" ,description = "From Rabbit it is taking Info")
public class ConsumerController {

	
	private ConsumerService consumerService;
	
	@ApiOperation(value = "Here we can see every account info",response = List.class)
	@GetMapping("/showall")
	public List<Account> showall()
	{
		return consumerService.showall();
	}
	
	@ApiOperation(value = "Here we can see Specific account info",response = Account.class)
	@GetMapping("/show/{id}")
	public Account showByid(@ApiParam(value = "Required id to search",required = true)@PathVariable int id)
	{
		return consumerService.showByid(id);
	}
}
