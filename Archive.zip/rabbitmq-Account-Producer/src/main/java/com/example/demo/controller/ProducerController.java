package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Account;
import com.example.demo.service.ProducerService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@Api(value = "Account Creation", description = "From here account sent to RabbitMq")
public class ProducerController {

	
	@Autowired
	private ProducerService producerService;
	
	@ApiOperation(value = "Function to create Account", response = String.class)
	@PostMapping("/create")
	public String create(@ApiParam(value = "Requires object od Account to save",required = true) @RequestBody Account acc)
	{
		producerService.sendMesage(acc);
		return "sent";
	}
}
